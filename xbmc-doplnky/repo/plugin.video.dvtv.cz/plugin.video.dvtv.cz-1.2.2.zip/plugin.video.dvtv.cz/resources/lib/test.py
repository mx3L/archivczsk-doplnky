import os
import sys
import re
import unittest
KODI_PATH = '/home/marko/Projects/Kodi/kodi-czsk2/'

filename = os.path.dirname( os.path.realpath(__file__) )
sys.path.append( os.path.join ( KODI_PATH,'script.module.stream.resolver','lib') )
sys.path.append( os.path.join ( KODI_PATH,'script.module.demjson','lib') )
sys.path.append( os.path.join ( KODI_PATH,'script.module.stream.resolver','lib','contentprovider') )
sys.path.append( os.path.join ( KODI_PATH,'script.module.stream.resolver','lib','server') )
import provider
import util
import dvtv

class TestJoj(unittest.TestCase):
    @classmethod
    def setUp(cls):
        cls.provider = dvtv.DVTVContentProvider()

    def test_vod_resolving(self):
        urls = ['https://video.aktualne.cz/dvtv/dvtv-8-3-2017-miroslav-taborsky-a-robert-brestan/r~9191981c040e11e7bb37002590604f2e/']
        for url in urls:
            res = self.provider.resolve({'url':url})
            print "'%s' - resolved %d videos" %(url, len(res))

if __name__ == "__main__":
    unittest.main()
