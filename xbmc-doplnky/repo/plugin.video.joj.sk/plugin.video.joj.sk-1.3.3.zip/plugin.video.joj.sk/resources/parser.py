import xml.etree.ElementTree as ET


def build_setting(setting_el):
    attrib = setting_el.attrib
    default = attrib['default']
    if attrib['type'] == 'text':
        if attrib['option'] == 'hidden':
            return ConfigPassword(default=default))
        else:
            return ConfigText(default=default)
    if attrib['type'] == 'bool':
        return ConfigYesNo(default=default)
    elif attrib['type'] == 'enum':
        choicelist = [(idx, toString(self._get_label(e))) 
                for idx, e in enumerate(attrib['lvalues'].split('|')]
        return ConfigSelection(default=default, choices=choicelist)
    elif attrib['type'] == 'labelenum':
        choicelist = [(toString(self._get_label(e)),)
                for e in attrib['values'].split("|")]
        return ConfigSelection(default=default, choices=choicelist)
    elif attrib['type'] == 'number':
        return ConfigNumber(default=int(default)))


if __name__ == "__main__":
    categories = {}
    root = ET.parse('../../plugin.video.online-files/resources/settings.xml').getroot()
    for element in root:
        if element.tag == 'category':
            category[element.attrib['label']] = []
            for el in element:
                if el.tag == 'setting':
                    setting = {}


            
        print element.items(), element.tag
        

