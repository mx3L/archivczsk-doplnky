import os
import sys
import re
import unittest

filename = os.path.dirname( os.path.realpath(__file__) )
sys.path.append( os.path.join ( filename, '..', '..', '..','script.module.stream.resolver','lib') )
sys.path.append( os.path.join ( filename, '..', '..', '..','script.module.demjson','lib') )
sys.path.append( os.path.join ( filename , '..','..', '..','script.module.stream.resolver','lib','contentprovider') )
sys.path.append( os.path.join ( filename , '..','..', '..','script.module.stream.resolver','lib','server') )

import provider
import util
import sosac


if __name__ == "__main__":
    unittest.main()
