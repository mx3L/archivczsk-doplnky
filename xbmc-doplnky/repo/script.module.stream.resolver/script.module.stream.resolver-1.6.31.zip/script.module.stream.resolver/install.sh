#!/bin/sh

E2_ADDON_PATH=/usr/lib/enigma2/python/Plugins/Extensions/archivCZSK/resources/repositories/xbmc_doplnky/script.module.stream.resolver

echo "INSTALLING script.module.stream.resolver TO $E2_USERNAME:$E2_PASSWORD@$E2_HOST"

tar -czf script.module.stream.resolver.tar.gz *

ftp -n $E2_HOST << EOFFTP
user $E2_USERNAME $E2_PASSWORD
binary
cd /tmp
put script.module.stream.resolver.tar.gz
bye
EOFFTP

sshpass -p $E2_PASSWORD ssh $E2_USERNAME@$E2_HOST << EOFSSH
cd $E2_ADDON_PATH
rm -rf *
tar -C $E2_ADDON_PATH -xzf /tmp/script.module.stream.resolver.tar.gz
rm -f /tmp/script.module.stream.resolver.tar.gz
EOFSSH

rm -f script.module.stream.resolver.tar.gz
