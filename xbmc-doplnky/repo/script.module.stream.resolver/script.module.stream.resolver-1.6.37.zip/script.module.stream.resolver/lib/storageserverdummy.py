'''
     StorageServer override.
     Version: 1.0
'''

import os
import datetime
try:
    from hashlib import md5
except ImportError:
    import md5.new as md5

class StorageServer:
    def __init__(self, table, timeout=24):
        self.timeout = timeout
        self.table = table
        self.cache_path = "/tmp/archivCZSK/cache"
        try:
            os.makedirs(self.cache_path)
        except Exception:
            pass

    def cacheFunction(self, funct=False, *args):
        argsstr = funct.__name__
        for arg in args:
            if isinstance(arg, object):
                argsstr += arg.__class__.__name__
            argsstr += str(arg)
        filename = self.table + "_"+ md5(argsstr).hexdigest()
        path = os.path.join(self.cache_path, filename)

        fromcache = False
        if os.path.isfile(path):
            date_now = datetime.datetime.now()
            date_cache = datetime.datetime.fromtimestamp(os.path.getmtime(path))
            delta_cache = date_now - date_cache
            delta_timeout = datetime.timedelta(hours=self.timeout)
            if delta_cache < delta_timeout:
                print '[StorageServer](%s,%dh) - cache file valid (%s)'%(
                        self.table, self.timeout, delta_timeout-delta_cache)
                fromcache = True
            else:
                print '[StorageServer](%s,%dh) - cache file no longer valid'%(
                        self.table, self.timeout)
        res = None
        if fromcache:
            try:
                with open(path, "r") as f:
                    res = f.read()
            except Exception:
                traceback.print_exc()

        if res is None:
            res = funct(*args)
            try:
                with open(path, "wb") as f:
                    f.write(res)
            except Exception:
                traceback.print_exc()
        return res

    def set(self, name, data):
        return ""

    def get(self, name):
        return ""

    def setMulti(self, name, data):
        return ""

    def getMulti(self, name, items):
        return ""

    def lock(self, name):
        return False

    def unlock(self, name):
        return False
