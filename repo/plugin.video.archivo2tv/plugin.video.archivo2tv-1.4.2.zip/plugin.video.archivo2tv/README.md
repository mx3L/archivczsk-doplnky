<h1>Archiv O2TV</h1>
<p>
Kodi doplňek Sledování O2TV umožňuje sledovaní O2TV.
<p>
<a href="https://www.xbmc-kodi.cz/prispevek-zpetne-sledovani-o2tv-ott">Vlákno na fóru XBMC-Kodi.cz</a><br><br>
Inspirovaný addonem pro zpětné sledování ze SledovaniTV od @Saros  jsem se snažil udělat něco podobného pro OTT O2TV. Doplněk umožnuje zpětné přehrávání pořadů a základní práci s nahrávkami.

Po instalaci doplňku je potřeba v nastavení zadat přihlašovací údaje (stejné jako na webu www.o2tv.cz), do Device Id libovolnou změť alfanumerických znaků, Device Name a Device Type budou předvyplněné.

v1.4.2 (2020-05-20)<br>
- u datumů se zobrazuje den v týdnu<br> 
- oprava načítání uživatelského seznamu kanálů, pokud obsahuje diakritiku<br>
- upravené titulek u položek ve vyhledání (sjednoceno s nahrávkami)<br>
- opravené zobrazení popisu u nahrávek<br><br>

v1.4.1 (2020-05-18)<br>
- přidání mazání a plánování nahrávek do kontextového menu (c)<br>
- zobrazení budoucího programu pro nastavení nahrávek (zobrazení detailů je možné samostatně zapnout v nastavení, načtení seznamu je ale výrazně pomalejší)<br>
- opravy chyb v nahrávkách<br><br> 

v1.4.0 (2020-05-16)<br>
- přejmenování addonu<br>
- generovaní device id, pokud není vyplněné<br>
- možnost skrýt položku Pořadí kanálů v menu<br>
- možnost načíst uživatelský seznam kanálů z O2, resetnout celý seznam, oprava chyby v pořadí kanálů<br>
- upravený formát titulku pořadu<br>
- přidáno přehrávání nahrávek<br>
- generování playlistu a streamu pro IPTV Simple Clienta<br><br>

v1.3.1 (2020-05-15)<br>
- oprava seznamu kanálů u více balíčků<br>
- nastavení historie<br><br>

v1.3.0 (2020-05-15)<br>
- přechod na jiné API O2<br>
- zrušení závislosti na InputStream Adaptive<br>
- volba SD/HD kvality v nastavení<br>
- možnost nastavení pokračování pořadu i po jeho skončení podle EPG<br>
- možnost vypnutí zobrazení detailních informace, log a posterů<br>
- doplnění informací k live streamu<br>
- historie vyhledávání<br>
- nastavení pořadí programů<br><br>

v1.2.3 (2020-05-11)<br>
- přidání do XBMC-Kodi CZ/SK repozitáře<br><br>

v1.2.0 (2020-05-10)<br>
- přidáno vyhledávání<br>
- zobrazení ratingu<br>
- jméno pořadu u živého streamu<br>
- ošetření chybného přihlášení<br><br>

v1.1.0 (2020-05-10)<br>
- přidáno živé vysílání<br><br>

v1.0.2 (2020-05-09)<br>
- přidaná kontrola nastavení, opravené filtrování kanálů podle balíčku O2TV<br><br>

v1.0.1 (2020-05-09)<br>
- upravené závislosti a opravená možná chyba s kódováním<br><br>

v1.0.0 (2020-05-07)<br><br>
- první vydání<br>
</p>
