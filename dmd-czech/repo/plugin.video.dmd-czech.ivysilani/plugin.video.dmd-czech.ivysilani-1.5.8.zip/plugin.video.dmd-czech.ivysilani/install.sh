#!/bin/sh

E2_ADDON_PATH=/usr/lib/enigma2/python/Plugins/Extensions/archivCZSK/resources/repositories/dmd_czech/plugin.video.dmd-czech.ivysilani

echo "INSTALLING plugin.video.dmd-czech.ivysilani TO $E2_USERNAME:$E2_PASSWORD@$E2_HOST"

tar -czf plugin.video.dmd-czech.ivysilani.tar.gz *

ftp -n $E2_HOST << EOFFTP
user $E2_USERNAME $E2_PASSWORD
binary
cd /tmp
put plugin.video.dmd-czech.ivysilani.tar.gz
bye
EOFFTP

sshpass -p $E2_PASSWORD ssh $E2_USERNAME@$E2_HOST << EOFSSH
cd $E2_ADDON_PATH
rm -rf *
tar -C $E2_ADDON_PATH -xzf /tmp/plugin.video.dmd-czech.ivysilani.tar.gz
rm -f /tmp/plugin.video.dmd-czech.ivysilani.tar.gz
EOFSSH

rm -f plugin.video.dmd-czech.ivysilani.tar.gz
